﻿Venom Platform v4.7 â€” Documentation Folder
------------------------------------------
This folder contains 6 standalone themed pages used for rebate and legal information.

Files:
- veu-rebate.html : Victorian Energy Upgrades Program
- stc-rebate.html : Federal STC rebate
- solar-homes.html : Victorian Solar Homes rebate
- terms.html : Website Terms of Use
- privacy.html : Privacy Policy
- ip.html : Intellectual Property Notice

All pages include the Suntech logo header, unified theme styling, and 'Back to Main Page' button linking to Venom_Platform_v4.7.html.

Use:
Unzip alongside the main Venom_Platform_v4.7.html file.
Open any HTML file in your browser to view.
